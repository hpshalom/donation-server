
# Donation Server

This small Node.js server securely generates a client token using Braintree. It's used by the front-end to enable credit card and Apple Pay donations.
